
package main;

import javax.swing.JOptionPane;


public class Main {

    public static void main(String[] args) {
    
        Funcoes.Chama.menu();
        
    }
    
}
