
package Funcoes;

import javax.swing.JOptionPane;

public class Chama {
    
    public static void menu(){
        
        
        String x = JOptionPane.showInputDialog(null, "Escolha uma opção\n1-Soma\n2-Subtração\n3-Multiplicação\n4-Divisão\n5-Sair");
        int op = Integer.parseInt(x);
        
        switch (op){
            
            case 1: 
                Operacoes.soma();
                break;
                
            case 2: 
                Operacoes.sub();
                break;
                
            case 3: 
                Operacoes.mult();
                break;
                
            case 4:
                Operacoes.div();
                break;
           
            case 5:
                System.out.println("Fechando aplicação");
                break;
                
            default:
                 JOptionPane.showMessageDialog(null, "Opção Inválida");
                      
        }
        
        
    }
    
}
