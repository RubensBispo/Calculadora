package Funcoes;

import javax.swing.JOptionPane;

public class Operacoes {
   
    public static String valor1="";
    public static double val1=0, val2=0 , resp=0;
    
    public static void soma(){
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o primeiro valor");
        val1 = Double.parseDouble(valor1);
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o segundo valor");
        val2 = Double.parseDouble(valor1);
   
       
        resp = val2 + val1;
        
        JOptionPane.showMessageDialog(null, resp);
        
       
    }
     
    public static void sub(){
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o primeiro valor");
        val1 = Double.parseDouble(valor1);
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o segundo valor");
        val2 = Double.parseDouble(valor1);
   
       
        double resp = val2 - val1;
        
        JOptionPane.showMessageDialog(null, resp);
        
       
    }
    
    public static void mult(){
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o primeiro valor");
        val1 = Double.parseDouble(valor1);
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o segundo valor");
        val2 = Double.parseDouble(valor1);
   
       
        double resp = val2 * val1;
        
        JOptionPane.showMessageDialog(null, resp);
        
       
    }
    
    public static void div(){
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o primeiro valor");
        val1 = Double.parseDouble(valor1);
        
        valor1 = JOptionPane.showInputDialog(null, "Digite o segundo valor");
        val2 = Double.parseDouble(valor1);
   
       
        double resp = val2 / val1;
        
        JOptionPane.showMessageDialog(null, resp);
        
       
    }
      
  
    
    
}
